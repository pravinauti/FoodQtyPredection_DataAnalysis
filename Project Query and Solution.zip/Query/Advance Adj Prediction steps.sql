

-- Advance Adj Prediction

--Step 1: Find only the weekdays (Monday to Friday) from the current date, skipping 
-- Saturday and Sunday.

 --Declare @Today Date =getdate()
 ----SET @Today='2025-06-25'
 -- ;WITH NextDays AS (
 --   SELECT  CAST(@Today AS DATE) AS DateValue, 1 AS DayNumber
 --   UNION ALL
 --   SELECT DATEADD(DAY, 1, DateValue), DayNumber + 1
 --   FROM NextDays
 --   WHERE DayNumber < 10  -- Check next 10 days to ensure 5 weekdays
	--)
	--SELECT TOP 5  DateValue, DATENAME(WEEKDAY, DateValue) AS DayName 
	--FROM NextDays
	--WHERE DATEPART(WEEKDAY, DateValue) NOT IN (1, 7)  -- Exclude Sunday (1) and Saturday (7)
	--ORDER BY DateValue

 --Step 2 : Update Code for AVG Prediction Qty

 --2.1 Copy the Avg Prediction code, remove the stored procedure, 
 --declare variables manually, and comment out the Weekday logic

--DECLARE 
--@Location varchar(20)='Mumbai'
--,@WeekDay Varchar(20)=Null

--BEGIN
--	Declare @NoOfWeek INT 
--	SET @NoOfWeek =(
--					select  count (distinct datepart(WEEK,Date)) NoOfWeek from Employee_Attendance 
--					where Status IN ('Present')
--					)

--	SELECT Location,WeekDay,Item,
--	(TotalQty/@NoOfWeek) as Avg_PredictionQty
--	FROM 
--	(
--		Select O.Location,
--		DATENAME(WEEKDAY,O.Order_Date) AS WeekDay,
--		O.Item, COUNT(Order_ID) AS TotalQty
--		from Employee_Food_Orders as O
--		INNER JOIN Employee_Attendance A ON O.Order_Date=A.Date AND O.Employee_ID=A.Employee_ID
--		WHERE A.Status IN ('Present')
--		AND A.Location=@Location
--		--AND DATENAME(WEEKDAY,O.Order_Date)=@WeekDay
--		GROUP BY O.Location,DATENAME(WEEKDAY,O.Order_Date),O.Item
--	)Sub
--	ORDER BY Location,WeekDay,Item
--END

--2.2 Copy the Weekday code, insert data into a temp table, 
--and create a CTE table for Avg Prediction.

--DECLARE 
--@Location varchar(20)='Mumbai'
--,@WeekDay Varchar(20)=Null

--BEGIN
--    -- Declaration 1
--	Drop table if exists #Temp
--	Declare @NoOfWeek INT 
--	SET @NoOfWeek =(
--					select  count (distinct datepart(WEEK,Date)) NoOfWeek from Employee_Attendance 
--					where Status IN ('Present')
--					)

--	-- Declation 2
--	Declare @Today Date =getdate()
	
--	;WITH NextDays AS (
--	SELECT  CAST(@Today AS DATE) AS DateValue, 1 AS DayNumber
--	UNION ALL
--	SELECT DATEADD(DAY, 1, DateValue), DayNumber + 1
--	FROM NextDays
--	WHERE DayNumber < 10  -- Check next 10 days to ensure 5 weekdays
--	)
--	SELECT TOP 5  DateValue, DATENAME(WEEKDAY, DateValue) AS DayName Into #Temp
--	FROM NextDays
--	WHERE DATEPART(WEEKDAY, DateValue) NOT IN (1, 7)  -- Exclude Sunday (1) and Saturday (7)
--	ORDER BY DateValue
--	--select * from #Temp
--	-- End Declarion 

--	-- Main Query Start from here 
--;With WeeklyAVGPrediction 
-- AS(
--		SELECT Location,WeekDay,Item,
--		(TotalQty/@NoOfWeek) as Avg_PredictionQty
--		FROM 
--		(
--			Select O.Location,
--			DATENAME(WEEKDAY,O.Order_Date) AS WeekDay,
--			O.Item, COUNT(Order_ID) AS TotalQty
--			from Employee_Food_Orders as O
--			INNER JOIN Employee_Attendance A ON O.Order_Date=A.Date AND O.Employee_ID=A.Employee_ID
--			WHERE A.Status IN ('Present')
--			AND A.Location=@Location
--			--AND DATENAME(WEEKDAY,O.Order_Date)=@WeekDay
--			GROUP BY O.Location,DATENAME(WEEKDAY,O.Order_Date),O.Item
--		)Sub
--	)

--	select * from WeeklyAVGPrediction
 
	
--END

--Step 3 : Find the Adjected Prediction

--DECLARE 
--@Location varchar(20)='Mumbai'
--,@WeekDay Varchar(20)=Null

--BEGIN
--    -- Declaration 1
--	Drop table if exists #Temp
--	Declare @NoOfWeek INT 
--	SET @NoOfWeek =(
--					select  count (distinct datepart(WEEK,Date)) NoOfWeek from Employee_Attendance 
--					where Status IN ('Present')
--					)

--	-- Declation 2
--	Declare @Today Date =getdate()
	
--	;WITH NextDays AS (
--	SELECT  CAST(@Today AS DATE) AS DateValue, 1 AS DayNumber
--	UNION ALL
--	SELECT DATEADD(DAY, 1, DateValue), DayNumber + 1
--	FROM NextDays
--	WHERE DayNumber < 10  -- Check next 10 days to ensure 5 weekdays
--	)
--	SELECT TOP 5  DateValue, DATENAME(WEEKDAY, DateValue) AS DayName Into #Temp
--	FROM NextDays
--	WHERE DATEPART(WEEKDAY, DateValue) NOT IN (1, 7)  -- Exclude Sunday (1) and Saturday (7)
--	ORDER BY DateValue
--	--select * from #Temp
--	-- End Declarion 

--	-- Main Query Start from here 
--;With WeeklyAVGPrediction 
-- AS(
--		SELECT Location,WeekDay,Item,
--		(TotalQty/@NoOfWeek) as Avg_PredictionQty
--		FROM 
--		(
--			Select O.Location,
--			DATENAME(WEEKDAY,O.Order_Date) AS WeekDay,
--			O.Item, COUNT(Order_ID) AS TotalQty
--			from Employee_Food_Orders as O
--			INNER JOIN Employee_Attendance A ON O.Order_Date=A.Date AND O.Employee_ID=A.Employee_ID
--			WHERE A.Status IN ('Present')
--			AND A.Location=@Location
--			--AND DATENAME(WEEKDAY,O.Order_Date)=@WeekDay
--			GROUP BY O.Location,DATENAME(WEEKDAY,O.Order_Date),O.Item
--		)Sub
--	),
--	WeeklyADJPrediction 
--	AS (
--		select * from WeeklyAVGPrediction
  
--	   )

--	   Select * from WeeklyADJPrediction

--END

--3.1 Understand the Impact Factor logic and add upcoming 
--holidays or events into the Event table.

--select * from Employee_Events_Holidays order by date 

--Insert Into Employee_Events_Holidays Values 
--('2025-06-23','Training Session-In Office','Mumbai',5),
--('2025-06-29','Weather- heavy rain','Mumbai',-4)

--3.2 Join the AvgCTE to the temporary table.

--DECLARE 
--@Location varchar(20)='Mumbai'
--,@WeekDay Varchar(20)=Null

--BEGIN
--    -- Declaration 1
--	Drop table if exists #Temp
--	Declare @NoOfWeek INT 
--	SET @NoOfWeek =(
--					select  count (distinct datepart(WEEK,Date)) NoOfWeek from Employee_Attendance 
--					where Status IN ('Present')
--					)

--	-- Declation 2
--	Declare @Today Date =getdate()
	
--	;WITH NextDays AS (
--	SELECT  CAST(@Today AS DATE) AS DateValue, 1 AS DayNumber
--	UNION ALL
--	SELECT DATEADD(DAY, 1, DateValue), DayNumber + 1
--	FROM NextDays
--	WHERE DayNumber < 10  -- Check next 10 days to ensure 5 weekdays
--	)
--	SELECT TOP 5  DateValue, DATENAME(WEEKDAY, DateValue) AS DayName Into #Temp
--	FROM NextDays
--	WHERE DATEPART(WEEKDAY, DateValue) NOT IN (1, 7)  -- Exclude Sunday (1) and Saturday (7)
--	ORDER BY DateValue
--	--select * from #Temp
--	-- End Declarion 

--	-- Main Query Start from here 
--;With WeeklyAVGPrediction 
-- AS(
--		SELECT Location,WeekDay,Item,
--		(TotalQty/@NoOfWeek) as Avg_PredictionQty
--		FROM 
--		(
--			Select O.Location,
--			DATENAME(WEEKDAY,O.Order_Date) AS WeekDay,
--			O.Item, COUNT(Order_ID) AS TotalQty
--			from Employee_Food_Orders as O
--			INNER JOIN Employee_Attendance A ON O.Order_Date=A.Date AND O.Employee_ID=A.Employee_ID
--			WHERE A.Status IN ('Present')
--			AND A.Location=@Location
--			--AND DATENAME(WEEKDAY,O.Order_Date)=@WeekDay
--			GROUP BY O.Location,DATENAME(WEEKDAY,O.Order_Date),O.Item
--		)Sub
--	),
--	WeeklyADJPrediction 
--	AS (
--		select 
--		WAP.Location as Location,
--		EEH.Date AS WeekDay,
--		WAP.Item as Category,
--		WAP.Avg_PredictionQty,
--		EEH.Event_Holiday,
--		EEH.ImpactFactor


	
--		from WeeklyAVGPrediction WAP
--		LEFT JOIN #Temp T ON WAP.WeekDay=t.DayName
--		LEFT JOIN Employee_Events_Holidays  EEH on EEH.Date=t.DateValue 
--		and EEH.Location=WAP.Location
--		--where wap.Location=@Location
  
--	   )

--	   Select * from WeeklyADJPrediction

--END

--3.3 Write the logic for the Impact Factor CASE statement.


--DECLARE 
--@Location varchar(20)='Mumbai'
--,@WeekDay Varchar(20)=Null

--BEGIN
--     Declaration 1
--	Drop table if exists #Temp
--	Declare @NoOfWeek INT 
--	SET @NoOfWeek =(
--					select  count (distinct datepart(WEEK,Date)) NoOfWeek from Employee_Attendance 
--					where Status IN ('Present')
--					)

--	 Declation 2
--	Declare @Today Date =getdate()
	
--	;WITH NextDays AS (
--	SELECT  CAST(@Today AS DATE) AS DateValue, 1 AS DayNumber
--	UNION ALL
--	SELECT DATEADD(DAY, 1, DateValue), DayNumber + 1
--	FROM NextDays
--	WHERE DayNumber < 10  -- Check next 10 days to ensure 5 weekdays
--	)
--	SELECT TOP 5  DateValue, DATENAME(WEEKDAY, DateValue) AS DayName Into #Temp
--	FROM NextDays
--	WHERE DATEPART(WEEKDAY, DateValue) NOT IN (1, 7)  -- Exclude Sunday (1) and Saturday (7)
--	ORDER BY DateValue
--	select * from #Temp
--	 End Declarion 

--	 Main Query Start from here 
--;With WeeklyAVGPrediction 
-- AS(
--		SELECT Location,WeekDay,Item,
--		(TotalQty/@NoOfWeek) as Avg_PredictionQty
--		FROM 
--		(
--			Select O.Location,
--			DATENAME(WEEKDAY,O.Order_Date) AS WeekDay,
--			O.Item, COUNT(Order_ID) AS TotalQty
--			from Employee_Food_Orders as O
--			INNER JOIN Employee_Attendance A ON O.Order_Date=A.Date AND O.Employee_ID=A.Employee_ID
--			WHERE A.Status IN ('Present')
--			AND A.Location=@Location
--			AND DATENAME(WEEKDAY,O.Order_Date)=@WeekDay
--			GROUP BY O.Location,DATENAME(WEEKDAY,O.Order_Date),O.Item
--		)Sub
--	),
--	WeeklyADJPrediction 
--	AS (
--		select 
--		WAP.Location as Location,
--		T.DateValue AS Date,
--		wap.WeekDay,
--		WAP.Item as Category,
--		WAP.Avg_PredictionQty,
--		EEH.Event_Holiday,
--		EEH.ImpactFactor,
--		CASE 
--		  WHEN EEH.ImpactFactor =-10 THEN WAP.Avg_PredictionQty *(1-1.00) 
--		  WHEN EEH.ImpactFactor =-9 THEN WAP.Avg_PredictionQty *(1-0.90) 
--		  WHEN EEH.ImpactFactor =-8 THEN WAP.Avg_PredictionQty *(1-0.80) 
--		  WHEN EEH.ImpactFactor =-7 THEN WAP.Avg_PredictionQty *(1-0.70) 
--		  WHEN EEH.ImpactFactor =-6 THEN WAP.Avg_PredictionQty *(1-0.60) 
--		  WHEN EEH.ImpactFactor =-5 THEN WAP.Avg_PredictionQty *(1-0.50) 
--		  WHEN EEH.ImpactFactor =-4 THEN WAP.Avg_PredictionQty *(1-0.40) 
--		  WHEN EEH.ImpactFactor =-3 THEN WAP.Avg_PredictionQty *(1-0.30) 
--		  WHEN EEH.ImpactFactor =-2 THEN WAP.Avg_PredictionQty *(1-0.20) 
--		  WHEN EEH.ImpactFactor =-1 THEN WAP.Avg_PredictionQty *(1-0.10) 
--		  WHEN EEH.ImpactFactor = 0 THEN WAP.Avg_PredictionQty 
--		  WHEN EEH.ImpactFactor = 1 THEN WAP.Avg_PredictionQty *(1+ 0.10) 
--		  WHEN EEH.ImpactFactor = 2 THEN WAP.Avg_PredictionQty *(1+ 0.20) 
--		  WHEN EEH.ImpactFactor = 3 THEN WAP.Avg_PredictionQty *(1+ 0.30) 
--		  WHEN EEH.ImpactFactor = 4 THEN WAP.Avg_PredictionQty *(1+ 0.40) 
--		  WHEN EEH.ImpactFactor = 5 THEN WAP.Avg_PredictionQty *(1+ 0.50) 
--		  WHEN EEH.ImpactFactor = 6 THEN WAP.Avg_PredictionQty *(1+ 0.60) 
--		  WHEN EEH.ImpactFactor = 7 THEN WAP.Avg_PredictionQty *(1+ 0.70) 
--		  WHEN EEH.ImpactFactor = 8 THEN WAP.Avg_PredictionQty *(1+ 0.80) 
--		  WHEN EEH.ImpactFactor = 9 THEN WAP.Avg_PredictionQty *(1+ 0.90) 
--		  WHEN EEH.ImpactFactor = 10 THEN WAP.Avg_PredictionQty *(1+1.00) 
--		  ELSE WAP.Avg_PredictionQty
--		  END  AS AdjPredictionQty
	
--		from WeeklyAVGPrediction WAP
--		LEFT JOIN  #Temp T ON WAP.WeekDay=T.DayName
--		LEFT JOIN  Employee_Events_Holidays EEH ON T.DateValue=EEH.Date AND EEH.Location=WAP.Location 
  
--	   )

--	   Select Location,Date,WeekDay,Category,Avg_PredictionQty,Event_Holiday,ImpactFactor,
--	   round(AdjPredictionQty,0) as AdjPredictionQty
--	   from WeeklyADJPrediction 
--	   ORDER BY Location,Date

--END


--Step 4 : Create Procedure with Input Parameter 

-- Exec sp_WeeklyFoodQtyPredictionAnalysis 'Mumbai','Monday'
ALTER PROCEDURE sp_WeeklyFoodQtyPredictionAnalysis
(

@Location varchar(20)='Mumbai'
,@WeekDay Varchar(20)=Null
)
AS
BEGIN
    -- Declaration 1
	Drop table if exists #Temp
	Declare @NoOfWeek INT 
	SET @NoOfWeek =(
					select  count (distinct datepart(WEEK,Date)) NoOfWeek from Employee_Attendance 
					where Status IN ('Present')
					)

	-- Declation 2
	Declare @Today Date =getdate()
	
	;WITH NextDays AS (
	SELECT  CAST(@Today AS DATE) AS DateValue, 1 AS DayNumber
	UNION ALL
	SELECT DATEADD(DAY, 1, DateValue), DayNumber + 1
	FROM NextDays
	WHERE DayNumber < 10  -- Check next 10 days to ensure 5 weekdays
	)
	SELECT TOP 5  DateValue, DATENAME(WEEKDAY, DateValue) AS DayName Into #Temp
	FROM NextDays
	WHERE DATEPART(WEEKDAY, DateValue) NOT IN (1, 7)  -- Exclude Sunday (1) and Saturday (7)
	ORDER BY DateValue
	--select * from #Temp
	-- End Declarion 

	-- Main Query Start from here 
;With WeeklyAVGPrediction 
 AS(
		SELECT Location,WeekDay,Item,
		(TotalQty/@NoOfWeek) as Avg_PredictionQty
		FROM 
		(
			Select O.Location,
			DATENAME(WEEKDAY,O.Order_Date) AS WeekDay,
			O.Item, COUNT(Order_ID) AS TotalQty
			from Employee_Food_Orders as O
			INNER JOIN Employee_Attendance A ON O.Order_Date=A.Date AND O.Employee_ID=A.Employee_ID
			WHERE A.Status IN ('Present')
			AND A.Location=@Location
			AND DATENAME(WEEKDAY,O.Order_Date)=@WeekDay
			GROUP BY O.Location,DATENAME(WEEKDAY,O.Order_Date),O.Item
		)Sub
	),
	WeeklyADJPrediction 
	AS (
		select 
		WAP.Location as Location,
		T.DateValue AS Date,
		wap.WeekDay,
		WAP.Item as Category,
		WAP.Avg_PredictionQty,
		EEH.Event_Holiday,
		EEH.ImpactFactor,
		CASE 
		  WHEN EEH.ImpactFactor =-10 THEN WAP.Avg_PredictionQty *(1-1.00) 
		  WHEN EEH.ImpactFactor =-9 THEN WAP.Avg_PredictionQty *(1-0.90) 
		  WHEN EEH.ImpactFactor =-8 THEN WAP.Avg_PredictionQty *(1-0.80) 
		  WHEN EEH.ImpactFactor =-7 THEN WAP.Avg_PredictionQty *(1-0.70) 
		  WHEN EEH.ImpactFactor =-6 THEN WAP.Avg_PredictionQty *(1-0.60) 
		  WHEN EEH.ImpactFactor =-5 THEN WAP.Avg_PredictionQty *(1-0.50) 
		  WHEN EEH.ImpactFactor =-4 THEN WAP.Avg_PredictionQty *(1-0.40) 
		  WHEN EEH.ImpactFactor =-3 THEN WAP.Avg_PredictionQty *(1-0.30) 
		  WHEN EEH.ImpactFactor =-2 THEN WAP.Avg_PredictionQty *(1-0.20) 
		  WHEN EEH.ImpactFactor =-1 THEN WAP.Avg_PredictionQty *(1-0.10) 
		  WHEN EEH.ImpactFactor = 0 THEN WAP.Avg_PredictionQty 
		  WHEN EEH.ImpactFactor = 1 THEN WAP.Avg_PredictionQty *(1+ 0.10) 
		  WHEN EEH.ImpactFactor = 2 THEN WAP.Avg_PredictionQty *(1+ 0.20) 
		  WHEN EEH.ImpactFactor = 3 THEN WAP.Avg_PredictionQty *(1+ 0.30) 
		  WHEN EEH.ImpactFactor = 4 THEN WAP.Avg_PredictionQty *(1+ 0.40) 
		  WHEN EEH.ImpactFactor = 5 THEN WAP.Avg_PredictionQty *(1+ 0.50) 
		  WHEN EEH.ImpactFactor = 6 THEN WAP.Avg_PredictionQty *(1+ 0.60) 
		  WHEN EEH.ImpactFactor = 7 THEN WAP.Avg_PredictionQty *(1+ 0.70) 
		  WHEN EEH.ImpactFactor = 8 THEN WAP.Avg_PredictionQty *(1+ 0.80) 
		  WHEN EEH.ImpactFactor = 9 THEN WAP.Avg_PredictionQty *(1+ 0.90) 
		  WHEN EEH.ImpactFactor = 10 THEN WAP.Avg_PredictionQty *(1+1.00) 
		  ELSE WAP.Avg_PredictionQty
		  END  AS AdjPredictionQty
	
		from WeeklyAVGPrediction WAP
		LEFT JOIN  #Temp T ON WAP.WeekDay=T.DayName
		LEFT JOIN  Employee_Events_Holidays EEH ON T.DateValue=EEH.Date AND EEH.Location=WAP.Location 
  
	   )

	   Select Location,Date,WeekDay,Category,Avg_PredictionQty,Event_Holiday,ImpactFactor,
	   round(AdjPredictionQty,0) as AdjPredictionQty
	   from WeeklyADJPrediction 
	   ORDER BY Location,Date

END
